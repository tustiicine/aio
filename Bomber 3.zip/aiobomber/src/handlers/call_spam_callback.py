from aiogram import Dispatcher
from aiogram.types import CallbackQuery

from assets.texts import textData,markupData
from src.db.db import check_vip

async def call_sms(call:CallbackQuery):
    await call.answer()
    if check_vip(call.from_user.id):
        await call.answer(textData.loading)
    else:
        await call.message.answer(textData.call_spam,reply_markup=markupData.buy_vip)

def register(dp:Dispatcher):
    dp.register_callback_query_handler(call_sms,lambda c: c.data == 'call_select')