from aiogram import Dispatcher
from aiogram.types import CallbackQuery
from aiogram.dispatcher import FSMContext

from src.states.state import Form

async def error_s(call:CallbackQuery,state:FSMContext):
    await call.message.delete()
    await state.finish()

def register(dp:Dispatcher):
    dp.register_callback_query_handler(error_s,lambda c: c.data == 'unknow',state=Form.sms_spam)