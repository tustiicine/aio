from aiogram import Dispatcher
from aiogram.types import CallbackQuery

from src.db.db import load_stop_or_ol_stop

async def spam_stoper(call:CallbackQuery):
    await load_stop_or_ol_stop(call,int(call.data.split('|')[1]),stop=True)
    await call.message.delete()
    

def register(dp:Dispatcher):
    dp.register_callback_query_handler(spam_stoper,lambda c:c.data.split('|')[0] == 'break')