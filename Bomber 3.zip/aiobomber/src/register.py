from aiogram import Dispatcher

from src.handlers import __all__
from importlib import import_module

def register_all(dp:Dispatcher):
    for i in __all__:
        _module = import_module(f'src.handlers.{i}')
        _module.register(dp)