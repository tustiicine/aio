from random import choice

def get_random_proxy():
    with open('assets/proxies/proxy.txt') as f:
        data = f.readlines()
    return choice(data).replace('\n','')
