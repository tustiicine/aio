from aiogram import Dispatcher
from aiogram.types import CallbackQuery

from assets.texts import textData,markupData

async def devcall(call:CallbackQuery):
    await call.answer('В разработке')

def register(dp:Dispatcher):
    dp.register_callback_query_handler(devcall,lambda c:c.data.split('|')[0] == 'buy')