from aiogram import Dispatcher
from aiogram.types import Message
from aiogram.dispatcher import FSMContext

from assets.texts import textData,markupData
from src.db.db import spammer
from src.states.state import Form

async def sms_spam(message:Message,state:FSMContext):
    _code = await spammer(message)
    if _code[0]:
        await message.answer(textData.spam_with_message(message,_code),reply_markup=markupData.stop(_code[1]))
        await state.finish()
    else:
        await message.answer(textData.spam_with_message(message,_code))

def register(dp:Dispatcher):
    dp.register_message_handler(sms_spam,state=Form.sms_spam)