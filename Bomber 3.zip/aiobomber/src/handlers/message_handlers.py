from aiogram import Dispatcher
from aiogram.types import Message,CallbackQuery

from src.db.db import new_user
from assets.texts import textData,markupData

async def stats_callback(call:CallbackQuery):
    await call.answer()
    await call.message.edit_text(textData.stats(),reply_markup=markupData.stats)

async def start_handler(message:Message):
    new_user(message.from_user.id)
    await message.answer(textData.start,reply_markup=markupData.start)

async def stats(message:Message):
    await message.answer(textData.stats(),reply_markup=markupData.stats_only_replace)

def register(dp:Dispatcher):
    dp.register_message_handler(start_handler,commands=['start'])
    dp.register_message_handler(stats, text=['📊 Статистика'])
    dp.register_callback_query_handler(stats_callback, lambda c: c.data == 'stata')