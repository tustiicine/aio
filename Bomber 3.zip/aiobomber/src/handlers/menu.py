from aiogram import Dispatcher
from aiogram.types import Message,CallbackQuery

from assets.texts import textData,markupData


async def menu_call(call:CallbackQuery):
    await call.answer()
    await call.message.edit_text(textData.menu,reply_markup=markupData.menu)

async def menu_handler(message:Message):
    await message.answer(textData.menu,reply_markup=markupData.menu)

def register(dp:Dispatcher):
    dp.register_callback_query_handler(menu_call,lambda c:c.data == 'back')
    dp.register_message_handler(menu_handler,text=['🧨 Меню'])