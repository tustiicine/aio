from aiogram import Dispatcher
from aiogram.types import CallbackQuery

from assets.texts import textData,markupData
from src.states.state import Form

async def spam_sms(call:CallbackQuery):
    await call.answer()
    await call.message.answer(textData.spam_sms,reply_markup=markupData.its_error)
    await Form.sms_spam.set()

def register(dp:Dispatcher):
    dp.register_callback_query_handler(spam_sms,lambda c: c.data == 'sms_select')