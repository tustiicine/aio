from aiogram import Dispatcher
from aiogram.types import Message

from assets.texts import textData,markupData
from config import ADMINS
from src.db.db import add_money_usr, no_money_usr

async def adms(message:Message):
    if message.from_user.id in ADMINS:
        arg = message.get_args().split()
        try:
            res = add_money_usr(arg[0],arg[1])
            await message.answer(textData.add_money_text % (arg[0],arg[1],res))
        except Exception as err:
            await message.answer(textData.errors % err)

async def no_adms(message:Message):
    if message.from_user.id in ADMINS:
        arg = message.get_args().split()
        try:
            res = no_money_usr(arg[0],arg[1])
            await message.answer(textData.no_money_text % (arg[0],arg[1],res))
        except Exception as err:
            await message.answer(textData.errors % err,parse_mode='')


def register(dp:Dispatcher):
    dp.register_message_handler(adms,commands=['add_money'])
    dp.register_message_handler(no_adms,commands=['no_money'])