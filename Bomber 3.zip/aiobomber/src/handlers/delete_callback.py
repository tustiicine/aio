from aiogram import Dispatcher
from aiogram.types import CallbackQuery

async def del_(call:CallbackQuery):
    await call.message.delete()

def register(dp:Dispatcher):
    dp.register_callback_query_handler(del_,lambda c: c.data == 'delete')