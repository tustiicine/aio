from aiogram import Dispatcher
from aiogram.types import CallbackQuery

from assets.texts import textData,markupData

async def helper(call:CallbackQuery):
    await call.answer()
    await call.message.edit_text(textData.helper_text,reply_markup=markupData.back_to_menu)

def register(dp:Dispatcher):
    dp.register_callback_query_handler(helper,lambda c:c.data == 'helper')