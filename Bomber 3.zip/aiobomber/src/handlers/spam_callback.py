from aiogram import Dispatcher
from aiogram.types import CallbackQuery

from assets.texts import textData,markupData

async def spamm(call:CallbackQuery):
    await call.answer()
    await call.message.edit_text(textData.spam_select,reply_markup=markupData.spam_selector)

def register(dp:Dispatcher):
    dp.register_callback_query_handler(spamm,lambda c:c.data == 'spam')