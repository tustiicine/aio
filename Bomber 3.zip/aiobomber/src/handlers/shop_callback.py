from aiogram import Dispatcher
from aiogram.types import CallbackQuery

from assets.texts import textData,markupData

async def shop_call(call:CallbackQuery):
    await call.answer()
    await call.message.edit_text(textData.shop_data,reply_markup=markupData.shop_item)

def register(dp:Dispatcher):
    dp.register_callback_query_handler(shop_call,lambda c: c.data == 'shop')