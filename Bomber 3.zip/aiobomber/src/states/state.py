from aiogram.dispatcher.filters.state import State, StatesGroup

class Form(StatesGroup):
    sms_spam = State()