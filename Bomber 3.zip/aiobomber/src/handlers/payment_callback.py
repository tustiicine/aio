from aiogram import Dispatcher
from aiogram.types import CallbackQuery

from assets.texts import textData,markupData
from src.payments.pay import verify_qiwi

async def selected_method(call:CallbackQuery):
    args = call.data.split('|')
    if len(args) == 1:
        await call.answer()
        await call.message.edit_text(textData.select_buy_type,reply_markup=markupData.select_buy_call)
    elif len(args) == 2:
        if args[1] == 'qiwi':
            await call.answer()
            await call.message.edit_text(textData.qiwiw(call),reply_markup=markupData.linker(call))
        elif args[1] == 'qiwi_true':
            res = await verify_qiwi(call.from_user.id)
            if res:
                await call.message.delete()
                await call.message.answer(textData.true_press % res)
            else:
                await call.answer(textData.not_404_found)
        else:
            await call.answer('🛠 В разработке')

def register(dp:Dispatcher):
    dp.register_callback_query_handler(selected_method, lambda c: c.data.split('|')[0] == 'add_balance')