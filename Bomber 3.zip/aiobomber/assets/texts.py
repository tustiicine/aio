from aiogram.types import ReplyKeyboardMarkup,\
    KeyboardButton,InlineKeyboardButton,\
        InlineKeyboardMarkup

from src.db.db import get_user,get_currently_user
from src.payments.pay import generate_link


class textData:
    start = '<b>⚡️ Добро пожаловать в AioBomber</b>\n\n<code>Данный бот, предназначен для массовой рассылки (спама) SMS-сообщений на заданный номер мобильного телефона</code>\n\n🛠 <i>Для навигации используйте кнопки</i>'
    menu = '<b>🖥 Меню бота AioBomber</b>'
    spam_select = '<b>🚪 Выберите тип спама</b>'
    spam_sms = '<b>💣 Введи номер телефона (без +, через 7) и время спама в минутах (1-20) через пробел</b>\n\n<i>Пример:</i> <code>79158008060 10</code>'
    helper_text = '<b>♻️ Поддержка бота AioBomber</b>\n\n<b>🤚 Администрация:</b>\n@ghtxfsh <b>- создатель</b>\n@ghtxfsh <b>- админ</b>\n\n⚡️ <b>Канал:</b> @ghtxfsh'
    loading = 'В разработке'
    call_spam = '<b>❌ Спам звонками доступен только при подписке!</b>'
    shop_data = '<b>🛠 Выберите необходимую категорию</b>'
    select_buy_type = '<b>Выберите способ оплаты</b>'
    true_press = '<b>✅ Ваш баланс был пополнен на %s руб</b>'
    not_404_found = '❌ Оплата не найдена'
    add_money_text = '<b>👤 Пользователю</b> <code>%s</code> <b>начисленно %s, теперь его баланс </b><code>%s</code>'
    no_money_text = '<b>👤 Пользователю</b> <code>%s</code> <b>снято %s, теперь его баланс </b><code>%s</code>'
    errors = '❌ Ошибка: %s'
    def qiwiw(message):
        return f'<b>Оплата QIWI</b>:\n\n👉 <b>Коментарий:</b> <code>{message.from_user.id}</code>\n👉 <b>Сумма:</b> <code>любая</code>\n\n<i>После оплаты нажмите на кнопку <b>проверить оплату</b></i>'
    def spam_with_message(message,_code):
        if _code[0]:
            return f'<b>✅ SMS спам активирован!</b>\n\n🎫 <b>Номер:</b> <code>{message.text.split()[0]}</code>\n<b>⏳ Время:</b> <code>{message.text.split()[1]} мин</code>'
        elif _code[1] == 0:
            return f'<b>❌ Все слоты заняты</b>'
        elif _code[1] == 1:
            return f'<b>❌ Неверно введены данные</b>'
        elif _code[1] == 2:
            return f'<b>❌ Номер введен неверно</b>'


    def me(user_id):
        user_data = get_currently_user(user_id)
        if not user_data:
            return '<b>❌ Пожалуйста нажмите /start</b>'
        return f'<b>📌 Мой аккаунт</b>\n<i>Вся необходимая информация о вашем профиле</i>\n\n🔗 <b>ID:</b> <code>{user_id}</code>\n💵 <b>Баланс</b>: <code>{user_data.money} руб</code>\n\n📝 <b>Подписка:</b> {"❌" if user_data.vip == False else "✅"}\n🧮 <b>Доступные слоты:</b> <code>{user_data.slots-user_data.use_slots}</code>'

    def stats():
        return f'<b>⛩ Количество пользователей AioBomber</b>\n\n<b>👤 Активных юзеров:</b> <code>{get_user()}</code>' 

class markupData:
    start = ReplyKeyboardMarkup(resize_keyboard=True).add(
        KeyboardButton('👤 Мой аккаунт'),KeyboardButton('📊 Статистика')
    ).add(
        KeyboardButton('🧨 Меню')
    )
    select_buy_call = InlineKeyboardMarkup().add(
        InlineKeyboardButton('🥝 QIWI',callback_data='add_balance|qiwi')
    ).add(
        InlineKeyboardButton('👈 Вернуться в меню',callback_data='back')
    )
    def linker(call):
        return InlineKeyboardMarkup().add(
        InlineKeyboardButton('Оплатить',url=generate_link(call.from_user.id))
    ).add(
        InlineKeyboardButton('✅ Проверить оплату',callback_data='add_balance|qiwi_true')
    ).add(
        InlineKeyboardButton('❌ Закрыть',callback_data='delete')
    )
    def stop(unique_id):
        return InlineKeyboardMarkup().add(
        InlineKeyboardButton('❌ Остановить спам',callback_data=f'break|{unique_id}')
    )
    buy_vip = InlineKeyboardMarkup().add(
        InlineKeyboardButton('💵 Купить подписку',callback_data='buy|vip'),
        InlineKeyboardButton('❌ Закрыть',callback_data='delete')
    )

    spam_selector =  InlineKeyboardMarkup().add(
        InlineKeyboardButton('💣 SMS спам',callback_data='sms_select'),
        InlineKeyboardButton('🧨 CALL спам',callback_data='call_select')
    ).add(
        InlineKeyboardButton('👈 Вернуться в меню',callback_data='back')
    )
    its_error = InlineKeyboardMarkup().add(
        InlineKeyboardButton('❌ Отмена',callback_data='unknow')
    )
    shop_item = InlineKeyboardMarkup().add(
        InlineKeyboardButton('✌️ Потоки',callback_data='buy|threads'),
        InlineKeyboardButton('🔥 Слоты',callback_data='buy|slots')
    ).add(
        InlineKeyboardButton('⚡️ Подписка',callback_data='buy|vip')
    ).add(
        InlineKeyboardButton('👈 Вернуться в меню',callback_data='back')
    )

    menu = InlineKeyboardMarkup().add(
        InlineKeyboardButton('⛩ Мой аккаунт',callback_data='me'),
        InlineKeyboardButton('📈 Статистика',callback_data='stata')
    ).add(
        InlineKeyboardButton('💣 Спам',callback_data='spam')
    ).add(
        InlineKeyboardButton('🏪 Магазин',callback_data='shop'),
        InlineKeyboardButton(text='🔫 Поддержка',callback_data='helper')
    )
    stats = InlineKeyboardMarkup().add(
        InlineKeyboardButton('🔄 Обновить',callback_data='replace'),
        InlineKeyboardButton('👈 Вернуться в меню',callback_data='back')
    )
    stats_only_replace = InlineKeyboardMarkup().add(
        InlineKeyboardButton('🔄 Обновить',callback_data='replace')
    )

    back_to_menu = InlineKeyboardMarkup().add(
        InlineKeyboardButton('👈 Вернуться в меню',callback_data='back')
    )

    me_call = InlineKeyboardMarkup().add(
        InlineKeyboardButton('Пополнить баланс',callback_data='add_balance') #https://www.tiktok.com/@juullest/video/7058264161658146050?is_copy_url=1&is_from_webapp=v1
    ).add(
        InlineKeyboardButton('👈 Вернуться в меню',callback_data='back')
    )
