from httpx import AsyncClient
from src.db.db import check_pay

def generate_link(_id):
    return f'https://qiwi.com/payment/form/99?amountInteger=&amountFraction=0&currency=643&extra%5B%27comment%27%5D={_id}&extra%5B%27account%27%5D=79165885068&blocked%5B0%5D=comment&blocked%5B1%5D=account'

async def verify_qiwi(_id):
    phone = "79165885068"
    token_qiwi = "ae60b6fc857f19bb407a70c5ee180d31"
    async with AsyncClient() as client:
        client.headers={"Accept":"application/json","Content-Type":"application/json","Authorization":"Bearer " + token_qiwi}

        parameters = {
            "rows": 3,
            "operation": "IN"
        }

        try:
            respons = await client.get("https://edge.qiwi.com/payment-history/v2/persons/"+ phone + "/payments?", params = parameters,timeout=10)
        except:
            return False

        for data in respons.json()["data"]:
            if data['comment'] == str(_id) and check_pay(data['txnId']):
                return int(data['sum']['amount'])



def verify_yoomoney(_id):
    return None
