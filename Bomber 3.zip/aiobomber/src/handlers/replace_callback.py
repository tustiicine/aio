from aiogram import Dispatcher
from aiogram.types import CallbackQuery

from assets.texts import textData,markupData

async def stats_update_callback(call:CallbackQuery):
    await call.answer()
    if call.message.html_text != textData.stats():
        await call.message.edit_text(textData.stats(),reply_markup=markupData.stats)

def register(dp:Dispatcher):
    dp.register_callback_query_handler(stats_update_callback, lambda c: c.data == 'replace')