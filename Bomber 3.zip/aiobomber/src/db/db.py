from datetime import datetime, timedelta
from aiogram.types import Message
from httpx import AsyncClient
from asyncio import create_task,gather,sleep
from assets.services.services import spam_start
from assets.proxies.proxy import get_random_proxy
from peewee import *

db = SqliteDatabase('src/db/db.sqlite3')

class Users(Model):
    id = PrimaryKeyField()
    money = IntegerField(default=0)
    threads = IntegerField(default=3)
    slots = IntegerField(default=1)
    use_slots = IntegerField(default=0)
    vip = BooleanField(default=False)

    class Meta:
        database = db

class SpamPhone(Model):
    user_id = IntegerField()
    phone = TextField()
    stop = BooleanField(default=False)
    stop_num = IntegerField(default=0)

    class Meta:
        database = db

class Payments(Model):
    txnId = PrimaryKeyField()

    class Meta:
        database = db

with db:
    db.create_tables([Users,SpamPhone,Payments])


def new_user(user_id:int):
    if not Users.select().where(Users.id==user_id).exists():
        Users.create(id=user_id)

def get_user():
    '''return users count'''
    return len(Users.select())

def check_pay(txnId:int):
    if not Payments.select().where(Payments.txnId == txnId).exists():
        Payments.create(txnId=txnId)
        return True

def check_vip(user_id:int):
    return Users.get(Users.id==user_id).vip

def get_currently_user(user_id:int) -> Users:
    if Users.select().where(Users.id==user_id).exists():
        return Users.get(Users.id==user_id)

def add_money_usr(user_id:int,summ:int) -> int:
    us = Users.get(Users.id == user_id).money+int(summ)
    Users.update(money=us).where(Users.id==user_id).execute()
    return us

def no_money_usr(user_id:int,summ:int) -> int:
    us = Users.get(Users.id == user_id).money-int(summ)
    Users.update(money=us).where(Users.id==user_id).execute()
    return us


async def load_stop_or_ol_stop(message:Message,unique_code:int,stop=False):
    if stop:
        SpamPhone.update(stop=True).where(SpamPhone.id==unique_code).execute()
    while SpamPhone.get_by_id(unique_code).stop_num != Users.get_by_id(message.from_user.id).threads:
        if SpamPhone.get_by_id(unique_code).stop:
            break
        await sleep(2)
    Users.update(use_slots=Users.get(Users.id==message.from_user.id).use_slots-1).where(Users.id==message.from_user.id).execute()
    text = '<b>✅ Спам успешно завершен!</b>'
    
    if stop:
        await message.message.answer(text)
    else:
        await message.answer(text)


async def spammer(message:Message):
    args = message.text.split()
    user = Users.get(Users.id==message.from_user.id)
    spam_lst = []

    if user.use_slots >= user.slots:
        return False,0
    elif len(args) != 2:
        return False,1
    elif len(args[0]) != 11 and len(args[0]) != 10:
        return False,2
    Users.update(use_slots=user.use_slots+1).where(Users.id==message.from_user.id).execute()

    get_spam = SpamPhone.create(user_id = message.from_user.id,phone=args[0])

    [spam_lst.append(create_task(spam_start(args[0], args[1],get_spam.id,datetime.now(),SpamPhone))) for _ in range(user.threads)]

    gather(*spam_lst)
    create_task(load_stop_or_ol_stop(message,get_spam.id))
    return True,get_spam.id

